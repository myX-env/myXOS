﻿=======================================
(C) 2025 myX Series 18 (XL)
myXLine - Inline Calculator v1.0 -
=======================================
[File Structure]
myXLine
├ myXLine.exe : Main program
└ readme.txt : This file

[System Requirements]
・Windows 7 / 8 / 10 / 11
・.NET Framework 4.8

[Overview]
Wherever text input is possible, simply select a mathematical
expression and press the hotkey to display the result.
Example: 2^2 → 2^2=4

[How to Use]
1. Launch myXLine.exe (it runs in the background).
2. Select the mathematical expression.
3. Press Ctrl+B.
4. "=result" is appended.

[Supported Operations]
+　-　*　/　^　(Exponentiation)
Calculations using parentheses () are also supported.

[Changing the Hotkey]
You can change the hotkey simply by renaming the EXE file.

myXLine.exe　　　Ctrl+B (Default)
myXLine_a.exe　　Ctrl+A
myXLine_x.exe　　Ctrl+X
myXLine_sp.exe　 Ctrl+Space
myXLine_sl.exe　 Ctrl+/
myXLine_sc.exe　 Ctrl+;
myXLine_cl.exe　 Ctrl+:
myXLine_dt.exe　 Ctrl+.
myXLine_cm.exe　 Ctrl+,
myXLine_mu.exe　 Ctrl+Muhenkan (Non-convert)

[Notes]
・The hotkey may not work due to conflicts with Windows or
other software, keyboard layout, or IME settings.
・If it does not work, please try renaming the file
to a different key name.・In rare cases, processing may fail,
but the clipboard contents will be restored.

【Prohibited】
・Redistributing this software while impersonating the author.
・Using this software for purposes that violate the law.

【Disclaimer】
The author assumes no responsibility whatsoever
for any direct or indirect damages arising
from the use of this software.
Please use it at your own risk.
=======================================
(C) 2025 myX Series 18 (XL)
=======================================

■ Update History

v1.0 - Initial release

■ Blog / Other Information

Official Blog:
http://blog.livedoor.jp/ldsano/

YouTube Channel:
https://www.youtube.com/@myX-env

=======================================
