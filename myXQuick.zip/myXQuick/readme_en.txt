﻿=======================================
(C) 2026 myX Series 20 (XQ)
myXQuick - Quick Call v1.0 -
=======================================
[File Structure]
myXQuick
├ myXQuick_Lite.exe	: Main executable
├ XQ.bat	: External startup batch file
├ LPause_Lite.exe	: Pause Key Trigger
├ readme.txt	: This file
└ readme_en.txt: English translation

[Development Environment]
・Windows 10
・.NET Framework 4.8

[Overview]
A memory-resident tool that summons the
myXKey (XK) key navigation
menu to the vicinity of the cursor
when the Pause/Break key is pressed.

[Usage]
Execution command:
myXQuick.exe "Program to launch" "Argument 1" "Argument 2" ...
Example:
myXQuick.exe "D:\app\Tool.exe" memo.txt test.txt
* The default target program is myXKey.exe.
* Switchable from the tray menu.
* When used with LPause_Lite.exe, 
  the Pause key can also be triggered by mouse input.

[Prohibited Actions]
Redistributing this software while impersonating the author.
Using this software for any purpose
that violates laws or regulations.

[Disclaimer]
The author assumes no responsibility for any damage
resulting from the use of this software.
Use at your own risk.

--- note ---
D:\
└ myX
    ├ myXKey      <Dir>
    ├ myXExeway   <Dir>
    └ myXQuick    <Dir>
        └ myXQuick_Lite.exe

Launch myXQuick_Lite.exe
Press the Pause key to launch myXKey
Select a mode from the tray menu

=======================================
(C) 2026 myX Series 20（XQ）
=======================================

■ Update History

v1.0 - Initial Release

■ Blog / Other Information

Official Website & Articles:
https://note.com/myxindex

Official Blog:
http://blog.livedoor.jp/ldsano/

YouTube Channel:
https://www.youtube.com/@myX-env

========================================
