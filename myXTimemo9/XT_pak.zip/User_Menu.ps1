# User.ps1
# �N���I�v�V�����FXB XE CM CMD PS EX

param(
    [string]$mode
)

Set-Location "D:\myX"

switch ($mode.ToUpper()) {
    "XB" {
        Push-Location "D:\myX\myXBlank"
        & ".\XB.bat" @args
        Pop-Location
    }
    "XE" {
        Start-Process "D:\myX\Exeway.exe" -ArgumentList $args
    }
    "CM" { Start-Process "cmd.exe" }
    "CMD"{ Start-Process "cmd.exe" }
    "PS" {
        Start-Process "powershell.exe" "-NoLogo -NoProfile"
    }
    "EX" {
        cmd /c "dir & pause"
    }
    default {
        if (Test-Path "_User.bat") {
            & ".\_User.bat"
        } elseif (Test-Path "D:\myX\myXAppBAT\menu.bat") {
            & "D:\myX\myXAppBAT\menu.bat"
        } else {
            & "D:\myX\myXAppBAT\myXFull.bat"
        }
    }
}
