# myX�A�v���N���p�i1�������͂��Ή��j
# ZIPRUN��p Mode_myX.ps1
# �I�v�V�����FA�`Z / XA�`XZ, EX=�e�X�g�p, CM/CMD/PS�Ȃ�

param(
    [string]$mode
)
Set-Location "D:\myX"
switch (("$mode").ToUpper()) {
    { $_ -in @("XA","A") } { Start-Process "D:\myX\myXAppBAT\menu.bat" }
    { $_ -in @("XB","B") } { Start-Process "D:\myX\myXBlank\XB.bat" }
    { $_ -in @("XC","C") } { Start-Process "D:\myX\myXConv\XC.bat" }
    { $_ -in @("XD","D") } { Start-Process "D:\myX\myXDiff\myXDiff.exe" }
    { $_ -in @("XE","E") } { Start-Process "D:\myX\myXExeway\Exeway.exe" }
    { $_ -in @("XF","F") } { Start-Process "D:\myX\myXFull\myXFull.bat" }
    { $_ -in @("XH","H") } { powershell -NoProfile -ExecutionPolicy Bypass `
        -File "D:\myX\myXHelper\myXHelper_Lite.ps1"
    }
    { $_ -in @("XK","K") } { Start-Process "D:\myX\myXKey\XK.bat" }
    { $_ -in @("XN","N") } { powershell -NoProfile -ExecutionPolicy Bypass `
        -File "D:\myX\myXName\myXName.ps1"
    }
    { $_ -in @("XP","P") } { Start-Process "D:\myX\myXPad\myXPad.exe" }
    { $_ -in @("XR","R") } { Start-Process "D:\myX\myXReturn\User.bat" }
    { $_ -in @("XS","S") } { Start-Process "D:\myX\myXSend\myXSend.exe" }
    { $_ -in @("XT","T") } { Start-Process "D:\myX\myXTimemo9\myXTimemo9.exe" }
    { $_ -in @("XV","V") } { Start-Process "D:\myX\myXView\myXView.exe" }
        { $_ -in @("XW","W") } { powershell -NoProfile -ExecutionPolicy Bypass `
        -File "D:\myX\myXWorker\myXWorker.ps1"
    }
    { $_ -in @("XZ","Z") } { Start-Process "D:\myX\myXZipRun\XZ.bat" }
    { $_ -in @("EX","X") } { cmd /c "dir & pause" } # �e�X�g�p---��
    { $_ -in @("CM","CMD") } { Start-Process "cmd.exe" }    
    "PS" { Start-Process "powershell.exe" "-NoLogo -NoProfile" }
    default {
        if (Test-Path "_User.bat") {
            & ".\_User.bat"
        } elseif (Test-Path "D:\myX\myXAppBAT\menu.bat") {
            & "D:\myX\myXAppBAT\menu.bat"
        } else {
            & "D:\myX\myXAppBAT\myXFull.bat"
        }
    }
}
